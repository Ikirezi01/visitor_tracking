
<?php
require_once 'User.php';
require_once 'Session.php';
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = new User();
    $session = new Session();

    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($user->login($username, $password)) {
        $session->startSession($_SESSION['user_id']);
        header("Location: dashboard.php");
        exit();
    } else {
        ?> <script>
        alert("Invalid username or password.");
    </script>
    
  <?php
    }
}
?>


<link rel="stylesheet" href="style.css"> 

<form method="POST">
    <h2>Login</h2>
     <label for="username">UserName</label>
    <input type="text" name="username" placeholder="Username" required>
     <label for="password">Password</label>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>

<p> Don't have an account?<a href="register.php">Register</a></p></form>
