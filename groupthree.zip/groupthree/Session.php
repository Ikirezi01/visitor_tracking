<?php
require_once 'Database.php';


class Session {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    public function startSession($user_id) {
        $query = "INSERT INTO sessions (user_id) VALUES (:user_id)";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute(['user_id' => $user_id]);
    }

    public function endSession($user_id) {
        $query = "UPDATE sessions SET logout_time = NOW() WHERE user_id = :user_id AND logout_time IS NULL";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute(['user_id' => $user_id]);
    }
}
?>
