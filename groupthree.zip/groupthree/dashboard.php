
<?php
session_start();

// Redirect to login if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>
<?php
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require_once 'Database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location:index.php");
    exit();
}

$database = new Database();
$conn = $database->connect();

// Pagination setup
$limit = 5;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$start = ($page - 1) * $limit;

$query = "SELECT * FROM sessions WHERE user_id = :user_id LIMIT $start, $limit";
$stmt = $conn->prepare($query);
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total records
$total_query = "SELECT COUNT(*) FROM sessions WHERE user_id = :user_id";
$stmt = $conn->prepare($total_query);
$stmt->execute(['user_id' => $_SESSION['user_id']]);
$total = $stmt->fetchColumn();
$pages = ceil($total / $limit);

echo "<h2>Session History</h2>";
foreach ($sessions as $session) {
    echo "<p>Login: " . $session['login_time'] . " | Logout: " . ($session['logout_time'] ?: "Active") . "</p>";
}

for ($i = 1; $i <= $pages; $i++) {
    echo "<a href='dashboard.php?page=$i'>$i</a> ";
}
?>

<a href="logout.php">Logout</a>
