<?php
require_once 'Session.php';
session_start();

if (isset($_SESSION['user_id'])) {
    $session = new Session();
    $session->endSession($_SESSION['user_id']);
}

session_unset();
session_destroy();


header("Location: index.php");
exit();
?>
